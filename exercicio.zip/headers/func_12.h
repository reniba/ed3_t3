#ifndef __FUNC_12__
#define __FUNC_12__

//#include "./bTreeHeaderRoutines.h"
//#include "./bTreeRoutines.h"
//#include "./funcoes_fornecidas.h"
#include "./graphAlgorithms.h"
#include "./graphRoutines.h"
#include "./messages.h"
//#include "./speciesRoutines.h"
#include <iostream>
#include <vector>
using namespace std;
//#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
int funcionality12(char inputFileName[], char query[]);
#endif // __FUNCIONALITIES__
