#include "./../headers/graphAlgorithms.h"
#include <cmath>
#include <cstdlib>
#include <utility>
#include <vector>

AUX_INDEX_MAP setIndexMap(GRAPH *graph)
{
    AUX_INDEX_MAP temp_map;
    for (int i = 0; i < graph->size(); i++)
    {
        // std::cout << (*graph)[i].first.name << " " << i << std::endl;
        temp_map.insert(std::make_pair((*graph)[i].first.name, i));
    }
    return temp_map;
}

void recursive_dfs(GRAPH *graph, AUX_INDEX_MAP *IndexMap, std::string node_name,
                   std::vector<bool> &visited)
{
    // std::cout << "Current Node: " << node_name << ' ' << (*IndexMap)[node_name] << std::endl;
    visited[(*IndexMap)[node_name]] = true;
    for (VECTOR_NODE food_node : (*graph)[(*IndexMap)[node_name]].second)
    {
        if (visited[(*IndexMap)[food_node.food]] == false)
            recursive_dfs(graph, IndexMap, food_node.food, visited);
    }
}

void dfs(GRAPH *graph, AUX_INDEX_MAP *IndexMap)
{
    std::vector<bool> visited(IndexMap->size(), false);
    recursive_dfs(graph, IndexMap, "achelousaurus", visited);
}

int dfs_number_of_cycles_rec(GRAPH *graph, AUX_INDEX_MAP *IndexMap, std::string node_name,
                             std::vector<bool> &visited, std::set<std::string> *excluded,
                             std::string origin_name)
{
    // std::cout << "Current Node: " << node_name << ' ' << (*IndexMap)[node_name] << std::endl;
    int resp = 0;
    visited[(*IndexMap)[node_name]] = true;
    // std::cout << (*graph)[3].first.name << std::endl;
    // std::cout << (*graph)[3].second.size() << std::endl; // 0 ??
    for (VECTOR_NODE food_node : (*graph)[(*IndexMap)[node_name]].second)
    {
        // std::cout << "olhando para a comida: " << food_node.food << " origem: " << origin_name
        //           << std::endl;
        if (food_node.food == origin_name)
            resp++;
        // if (((*excluded).contains(food_node.food)) == false &&
        if (visited[(*IndexMap)[food_node.food]] == false)
            dfs_number_of_cycles_rec(graph, IndexMap, food_node.food, visited, excluded,
                                     origin_name);
    }
    return resp;
}

int dfs_number_of_cycles(GRAPH *graph, AUX_INDEX_MAP *IndexMap)
{
    int resp = 0;
    std::set<std::string> excluded = {};
    for (int i = 0; i < graph->size(); i++)
    {
        std::vector<bool> visited(IndexMap->size(), false);
        resp += dfs_number_of_cycles_rec(graph, IndexMap, (*graph)[i].first.name, visited,
                                         &excluded, (*graph)[i].first.name);
        excluded.insert((*graph)[i].first.name);
    }
    /*std::vector<bool> visited(IndexMap->size(), false);
    std::cout << dfs_number_of_cycles_rec(graph, IndexMap, "abelisaurus", visited, &excluded,
                                          "abelisaurus")
              << std::endl;
    excluded.insert((*graph)[0].first.name);*/

    return resp;
}
