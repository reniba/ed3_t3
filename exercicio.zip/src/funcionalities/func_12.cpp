// para cada vértice do grafo
// realize uma dfs
//
// se a dfs retornar ao nó inicial +1;
//
// adicionar esse vértice como marcado
//
// realizar dfs novamente sem passar pelos nós marcados
//
#include "./../../headers/func_12.h"
#include <algorithm>
#include <initializer_list>
#include <utility>

// INSERT funcionality
int funcionality12(char DinosaurData_filename[], char input[])
{
    GRAPH graph;
    initializeGraph(&graph, DinosaurData_filename);
    // printGraph(&graph);
    AUX_INDEX_MAP IndexMap = setIndexMap(&graph);
    // cout << IndexMap["abelisaurus"] << endl;
    // printGraph(&graph);
    // dfs(&graph, &IndexMap);
    cout << "Quantidade de ciclos: " << dfs_number_of_cycles(&graph, &IndexMap) << endl;

    return EXIT_SUCCESS;
}
